blessing.i18n.examplePlugin = {
  test: 'JavaScript i18n test: English'
}
